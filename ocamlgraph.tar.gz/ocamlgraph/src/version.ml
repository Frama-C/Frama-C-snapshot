let version = "1.8.5+dev"
let date = "Tue Jan 27 10:39:23 CET 2015"
