let version = "1.8.2+svn"
let date = "Wed Jun 27 10:02:02 CEST 2012"
