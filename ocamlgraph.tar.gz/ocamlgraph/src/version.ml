let version = "1.4"
let date = "lundi 29 mars 2010, 11:31:14 (UTC+0200)"
