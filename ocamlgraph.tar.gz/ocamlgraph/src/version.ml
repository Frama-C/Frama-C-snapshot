let version = "1.6+dev"
let date = "jeudi 6 janvier 2011, 15:30:52 (UTC+0100)"
