let version = "1.7+dev"
let date = "jeudi 6 octobre 2011, 13:24:10 (UTC+0200)"
