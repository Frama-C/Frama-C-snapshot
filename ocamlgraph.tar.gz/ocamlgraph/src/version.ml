let version = "1.2+dev"
let date = "lundi 21 septembre 2009, 16:16:11 (UTC+0200)"
