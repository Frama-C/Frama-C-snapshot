let version = "1.0"
let date = "mardi 2 décembre 2008, 08:40:10 (UTC+0100)"
