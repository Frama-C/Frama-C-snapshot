let version = "1.8.2+svn"
let date = "Wed Apr 17 14:11:13 CEST 2013"
